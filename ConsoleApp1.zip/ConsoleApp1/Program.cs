﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welke tekst wil je ontcijferen: ");
            string text = Console.ReadLine();
            Console.WriteLine();
            frequentTable(text);
            Console.WriteLine();
            decrypt(text);
        }

        private static void frequentTable(string text)
        {
            int lengte = text.Length;
            int index = 0;
            int a = 0;
            int b = 0;
            int c = 0;
            int d = 0;
            int e = 0;
            int f = 0;
            int g = 0;
            int h = 0;
            int i = 0;
            int j = 0;
            int k = 0;
            int l = 0;
            int m = 0;
            int n = 0;
            int o = 0;
            int p = 0;
            int q = 0;
            int r = 0;
            int s = 0;
            int t = 0;
            int u = 0;
            int v = 0;
            int w = 0;
            int x = 0;
            int y = 0;
            int z = 0;

            while (index < lengte)
            {
                char letter = text[index];
                switch (letter)
                {
                    case 'A':
                        a++;
                        break;
                    case 'B':
                        b++;
                        break;
                    case 'C':
                        c++;
                        break;
                    case 'D':
                        d++;
                        break;
                    case 'E':
                        e++;
                        break;
                    case 'F':
                        f++;
                        break;
                    case 'G':
                        g++;
                        break;
                    case 'H':
                        h++;
                        break;
                    case 'I':
                        i++;
                        break;
                    case 'J':
                        j++;
                        break;
                    case 'K':
                        k++;
                        break;
                    case 'L':
                        l++;
                        break;
                    case 'M':
                        m++;
                        break;
                    case 'N':
                        n++;
                        break;
                    case 'O':
                        o++;
                        break;
                    case 'P':
                        p++;
                        break;
                    case 'Q':
                        q++;
                        break;
                    case 'R':
                        r++;
                        break;
                    case 'S':
                        s++;
                        break;
                    case 'T':
                        t++;
                        break;
                    case 'U':
                        u++;
                        break;
                    case 'V':
                        v++;
                        break;
                    case 'W':
                        w++;
                        break;
                    case 'X':
                        x++;
                        break;
                    case 'Y':
                        y++;
                        break;
                    case 'Z':
                        z++;
                        break;
                }
                index++;
            }
            Console.WriteLine("A:" + a.ToString());
            Console.WriteLine("B:" + b.ToString());
            Console.WriteLine("C:" + c.ToString());
            Console.WriteLine("D:" + d.ToString());
            Console.WriteLine("E:" + e.ToString());
            Console.WriteLine("F:" + f.ToString());
            Console.WriteLine("G:" + g.ToString());
            Console.WriteLine("H:" + h.ToString());
            Console.WriteLine("I:" + i.ToString());
            Console.WriteLine("J:" + j.ToString());
            Console.WriteLine("K:" + k.ToString());
            Console.WriteLine("L:" + l.ToString());
            Console.WriteLine("M:" + m.ToString());
            Console.WriteLine("N:" + n.ToString());
            Console.WriteLine("O:" + o.ToString());
            Console.WriteLine("P:" + p.ToString());
            Console.WriteLine("Q:" + q.ToString());
            Console.WriteLine("R:" + r.ToString());
            Console.WriteLine("S:" + s.ToString());
            Console.WriteLine("T:" + t.ToString());
            Console.WriteLine("U:" + u.ToString());
            Console.WriteLine("V:" + v.ToString());
            Console.WriteLine("W:" + w.ToString());
            Console.WriteLine("X:" + x.ToString());
            Console.WriteLine("Y:" + y.ToString());
            Console.WriteLine("Z:" + z.ToString());
            Console.ReadLine();
        }

        private static void decrypt(string input)
        {
            char[] text = input.ToCharArray();
            int lengte = text.Length;
            int index = 0;
            while (index < lengte)
            {
                char letter = text[index];
                switch (letter)
                {
                    case 'A':
                        text[index] = 'a';
                        break;
                    case 'B':
                        text[index] = 'y';
                        break;
                    case 'D':
                        text[index] = 'm';
                        break;
                    case 'E':
                        text[index] = 'c';
                        break;
                    case 'F':
                        text[index] = 'n';
                        break;
                    case 'G':
                        text[index] = 'o';
                        break;
                    case 'H':
                        text[index] = 'p';
                        break;
                    case 'I':
                        text[index] = 'h';
                        break;
                    case 'J':
                        text[index] = 'q';
                        break;
                    case 'K':
                        text[index] = 'r';
                        break;
                    case 'L':
                        text[index] = 's';
                        break;
                    case 'M':
                        text[index] = 't';
                        break;
                    case 'N':
                        text[index] = 'z';
                        break;
                    case 'O':
                        text[index] = 'i';
                        break;
                    case 'P':
                        text[index] = 'j';
                        break;
                    case 'Q':
                        text[index] = 'k';
                        break;
                    case 'R':
                        text[index] = 'd';
                        break;
                    case 'S':
                        text[index] = 'l';
                        break;
                    case 'T':
                        text[index] = 'e';
                        break;
                    case 'U':
                        text[index] = 'g';
                        break;
                    case 'X':
                        text[index] = 'v';
                        break;
                    case 'Y':
                        text[index] = 'f';
                        break;
                    case 'W':
                        text[index] = 'u';
                        break;
                    case 'Z':
                        text[index] = 'b';
                        break;
                }
                index++;
            }
            string output = new string(text);
            Console.WriteLine(output.ToUpper());
            Console.ReadLine();
        } 
    }
}
